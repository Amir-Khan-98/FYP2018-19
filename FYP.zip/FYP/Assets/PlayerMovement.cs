﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    public Rigidbody rb;
    public float forwardforce = 2000f;
    public float Mov = 750f;
    public float jumpForce = 2.0f;
    public bool isGrounded;
    // Use this for initialization
    void Start () {
        //rb.useGravity = false;
        //rb.AddForce(0, 200, 500);
        rb = GetComponent<Rigidbody>();
    }
    void OnCollisionStay()
    {
        isGrounded = true;
    }
    // Update is called once per frame
    void FixedUpdate () {
        
        //rb.AddForce(0, 0, forwardforce*Time.deltaTime);

        if (Input.GetKey("d"))
        {
            rb.AddForce(0,0, Mov * Time.deltaTime);
        }
        if (Input.GetKey("a"))
        {
            rb.AddForce(0, 0, -Mov * Time.deltaTime);
        }
        if (Input.GetKey("w") && isGrounded)
        {
            rb.AddForce(new Vector3(0, jumpForce, 0), ForceMode.Impulse);
            isGrounded = false;
        }
    }

}
